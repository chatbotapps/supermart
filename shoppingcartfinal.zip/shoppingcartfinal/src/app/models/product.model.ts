export class Product {
    category: string;
    productName: string;
    price: number;
    description: string;
    imgLink: string;
    quantity?: number;
}