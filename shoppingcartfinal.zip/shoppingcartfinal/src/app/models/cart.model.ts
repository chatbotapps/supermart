import { Product } from './product.model';

export class Cart {
    items: Product[];
    note: string;
}