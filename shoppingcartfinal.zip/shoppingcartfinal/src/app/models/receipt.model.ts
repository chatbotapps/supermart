export class Receipt {
    product: string;
    ' X ';
    quantity: number;
}